angular.module('Cartilla.controllers',[])

	.controller('listadoCtrl', function($scope) {
		$scope.mensaje= 'Holiss';
	})

	.controller('mapaCtrl', function($scope) {
		$scope.mensaje = 'SOS UN PUTO DE MIERDA CHAU';
	})