angular.module('BailamosApp.services', [])

.service('Parsito', function(){

    this.ParsearArray = function(response){
       //var variable = response.map(function(elem){elem.coords = {"latitude":elem.latitude,"longitude":elem.longitude}} );
       //return variable;
    }

});